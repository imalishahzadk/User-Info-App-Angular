import { Component, Input } from '@angular/core';
import { ClindaCountry } from '../classClinda';

@Component({
  selector: 'app-clinda-country',
  templateUrl: './clinda-country.component.html',
  styleUrls: ['./clinda-country.component.css'],
})
export class ClindaCountryComponent {
  @Input() clindaData: ClindaCountry = {} as ClindaCountry;
}
