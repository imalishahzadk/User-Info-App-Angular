
export class ClindaPersonal {
  clindaName: string;
  clindaID: string;
  clindaLogin: string;
  clindaEmail: string;
  clindaCampus: string;
  clindaImage: string;

  constructor() {
    this.clindaName = 'Clinda Smith';
    this.clindaID = '123456789';
    this.clindaLogin = 'clindasmith';
    this.clindaEmail = 'clinda.smith@sheridancollege.ca';
    this.clindaCampus = 'Trafalgar';
    this.clindaImage = 'usr.png';
  }
}

export class ClindaCountry {
  clindaCountry: string;
  clindaCountryID: number;
  clindaCountryCapital: string;
  clindaCountryAverageSalary: number;
  clindaFlagImage: string;

  constructor() {
    this.clindaCountry = 'Canada';
    this.clindaCountryID = 124; 
    this.clindaCountryCapital = 'Ottawa';
    this.clindaCountryAverageSalary = 55000; 
    this.clindaFlagImage = 'canada.png'; 
  }
}
