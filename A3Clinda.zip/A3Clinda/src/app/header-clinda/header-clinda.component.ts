import { Component, Input } from '@angular/core';
import { ClindaPersonal } from '../classClinda';

@Component({
  selector: 'app-header-clinda',
  templateUrl: './header-clinda.component.html',
  styleUrls: ['./header-clinda.component.css'],
})
export class HeaderClindaComponent {
  @Input() clindaChild: ClindaPersonal = {} as ClindaPersonal;
  currentDate: string = new Date().toLocaleString('en-US', {
    timeZoneName: 'short',
  });
}
