import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderClindaComponent } from './header-clinda.component';

describe('HeaderClindaComponent', () => {
  let component: HeaderClindaComponent;
  let fixture: ComponentFixture<HeaderClindaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HeaderClindaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HeaderClindaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
