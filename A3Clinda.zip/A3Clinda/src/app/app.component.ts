import { Component } from '@angular/core';
import { ClindaPersonal, ClindaCountry } from './classClinda';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'A3Clinda';
  PERclinda = new ClindaPersonal();
  CTRYclinda = new ClindaCountry();
}
