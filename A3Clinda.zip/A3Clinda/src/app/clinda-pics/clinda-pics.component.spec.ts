import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClindaPicsComponent } from './clinda-pics.component';

describe('ClindaPicsComponent', () => {
  let component: ClindaPicsComponent;
  let fixture: ComponentFixture<ClindaPicsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ClindaPicsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClindaPicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
