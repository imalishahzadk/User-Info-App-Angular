
import { Component, Input, OnInit } from '@angular/core';
import { ClindaPersonal, ClindaCountry } from '../classClinda';

@Component({
  selector: 'app-clinda-pics',
  templateUrl: './clinda-pics.component.html',
  styleUrls: ['./clinda-pics.component.css'],
})
export class ClindaPicsComponent implements OnInit {
  @Input() clindaMe: ClindaPersonal = {} as ClindaPersonal;
  @Input() clindaData: ClindaCountry = {} as ClindaCountry;

  currentImage: string = '';
  showPersonal: boolean = true;
  figureCaption: string = ''; 

  ngOnInit(): void {
    // Default view
    this.currentImage = this.clindaMe.clindaImage;
    this.figureCaption = this.clindaMe.clindaName;
  }

  displayPersonal(): void {
    this.currentImage = this.clindaMe.clindaImage;
    this.showPersonal = true;
    this.figureCaption = this.clindaMe.clindaName;
  }

  displayCountry(): void {
    this.currentImage = this.clindaData.clindaFlagImage;
    this.showPersonal = false;
    this.figureCaption = this.clindaData.clindaCountry;
  }
}
