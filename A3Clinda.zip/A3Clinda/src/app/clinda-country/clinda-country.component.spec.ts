import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClindaCountryComponent } from './clinda-country.component';

describe('ClindaCountryComponent', () => {
  let component: ClindaCountryComponent;
  let fixture: ComponentFixture<ClindaCountryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ClindaCountryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClindaCountryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
