import { Component, Input } from '@angular/core';
import { ClindaPersonal } from '../classClinda';

@Component({
  selector: 'app-clinda-about',
  templateUrl: './clinda-about.component.html',
  styleUrls: ['./clinda-about.component.css'],
})
export class ClindaAboutComponent {
  @Input() clindaMe: ClindaPersonal = {} as ClindaPersonal;
}
