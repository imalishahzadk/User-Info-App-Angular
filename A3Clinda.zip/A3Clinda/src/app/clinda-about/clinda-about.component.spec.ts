import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClindaAboutComponent } from './clinda-about.component';

describe('ClindaAboutComponent', () => {
  let component: ClindaAboutComponent;
  let fixture: ComponentFixture<ClindaAboutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ClindaAboutComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClindaAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
