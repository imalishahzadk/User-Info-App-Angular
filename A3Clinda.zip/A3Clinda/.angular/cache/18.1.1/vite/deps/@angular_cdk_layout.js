import {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
} from "./chunk-2W645GTK.js";
import "./chunk-4BLODCOO.js";
import "./chunk-W5HNGRYJ.js";
import "./chunk-MAENTQAE.js";
export {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
};
//# sourceMappingURL=@angular_cdk_layout.js.map
